
import trajectories
import loader 
# from torch.utils.data import DataLoader

# from sgan.data.trajectories import TrajectoryDataset, seq_collate

### 
import argparse # important

import gc
import logging
import os
import sys
import time


data_dir = "/Users/bryanzhao/24787-pedestrian/sgan/scripts/datasets/eth/train"
# data = trajectories.read_file(data_dir)

parser = argparse.ArgumentParser()

parser.add_argument('--input_size', type=int, default=2)
parser.add_argument('--output_size', type=int, default=5)
# RNN size parameter (dimension of the output/hidden state)
parser.add_argument('--rnn_size', type=int, default=128,
                    help='size of RNN hidden state')
# Size of each batch parameter
parser.add_argument('--batch_size', type=int, default=5,
                    help='minibatch size')
# Length of sequence to be considered parameter
parser.add_argument('--seq_length', type=int, default=20,
                    help='RNN sequence length')
parser.add_argument('--pred_length', type=int, default=12,
                    help='prediction length')
# Number of epochs parameter
parser.add_argument('--num_epochs', type=int, default=30,
                    help='number of epochs')
# Frequency at which the model should be saved parameter
parser.add_argument('--save_every', type=int, default=400,
                    help='save frequency')
# TODO: (resolve) Clipping gradients for now. No idea whether we should
# Gradient value at which it should be clipped
parser.add_argument('--grad_clip', type=float, default=10.,
                    help='clip gradients at this value')
# Learning rate parameter
parser.add_argument('--learning_rate', type=float, default=0.003,
                    help='learning rate')
# Decay rate for the learning rate parameter
parser.add_argument('--decay_rate', type=float, default=0.95,
                    help='decay rate for rmsprop')
# Dropout not implemented.
# Dropout probability parameter
parser.add_argument('--dropout', type=float, default=0.5,
                    help='dropout probability')
# Dimension of the embeddings parameter
parser.add_argument('--embedding_size', type=int, default=64,
                    help='Embedding dimension for the spatial coordinates')
# Size of neighborhood to be considered parameter
parser.add_argument('--neighborhood_size', type=int, default=32,
                    help='Neighborhood size to be considered for social grid')
# Size of the social grid parameter
parser.add_argument('--grid_size', type=int, default=4,
                    help='Grid size of the social grid')
# Maximum number of pedestrians to be considered
parser.add_argument('--maxNumPeds', type=int, default=27,
                    help='Maximum Number of Pedestrians')

# Lambda regularization parameter (L2)
parser.add_argument('--lambda_param', type=float, default=0.0005,
                    help='L2 regularization parameter')
# Cuda parameter
parser.add_argument('--use_cuda', action="store_true", default=False,
                    help='Use GPU or not')
# GRU parameter
parser.add_argument('--gru', action="store_true", default=False,
                    help='True : GRU cell, False: LSTM cell')
# drive option
parser.add_argument('--drive', action="store_true", default=False,
                    help='Use Google drive or not')
# number of validation will be used
parser.add_argument('--num_validation', type=int, default=2,
                    help='Total number of validation dataset for validate accuracy')
# frequency of validation
parser.add_argument('--freq_validation', type=int, default=1,
                    help='Frequency number(epoch) of validation using validation data')
# frequency of optimazer learning decay
parser.add_argument('--freq_optimizer', type=int, default=8,
                    help='Frequency number(epoch) of learning decay for optimizer')
# store grids in epoch 0 and use further.2 times faster -> Intensive memory use around 12 GB
parser.add_argument('--grid', action="store_true", default=True,
                    help='Whether store grids and use further epoch')

# Dataset options
parser.add_argument('--dataset_name', default='zara1', type=str)
parser.add_argument('--delim', default='\t')
parser.add_argument('--loader_num_workers', default=4, type=int)
parser.add_argument('--obs_len', default=8, type=int)
parser.add_argument('--pred_len', default=8, type=int)
parser.add_argument('--skip', default=1, type=int)

args = parser.parse_args()


# In[67]:

dataset, dataloader = loader.data_loader(args, data_dir)

# for i, fucker in enumerate(dataloader):
#      print("this is fucker's shape:\n", len(fucker)) # returns list of 7
#      for j, subfucker in enumerate(fucker):
#           # print("this is subfucker\n", subfucker)
#           print("subfucker's shape\n", subfucker.shape)

print(dataset)
print(dataloader)

